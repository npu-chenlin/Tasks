#include <iostream>

int main(int argc, char const *argv[])
{
	/* code */
	return 0;
}

template <typename T> void insertSort(T d[] , int n)
{
	T key;
	int j;
	for (j = 1; j < n; ++j)
	{
		key = d[j];
		for (int i = 0; i < j; ++i)
		{
			if (key > d[i])
			{
				
			}
		}
	}
}
